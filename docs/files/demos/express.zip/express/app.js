var express = require('express');
var path    = require('path');
var index   = require('./routes/index');                // 引入index.js路由配置文件

var app = express();                                    // 用express创建一个app应用
// view engine setup
app.set('views',       path.join(__dirname, 'views'));  // 指定视图文件夹 views/
app.set('view engine', 'ejs');                          // 指定视图引擎 ejs
app.all('*', (req, res, next) => {
    // 跨域设置
    res.header('Access-Control-Allow-Origin',  '*');
    res.header('Cross-Origin-Embedder-Policy', 'require-corp');
    res.header('Cross-Origin-Opener-Policy',   'same-origin'); 
    next();
})

// 设置静态资源路径
app.use(express.static(path.join(__dirname, 'dist')));  // 指定公共资源文件夹 为public/
// 路由规则
app.use('/', index);                                    // 当路径为'/'，即'https://localhost:443/'时，匹配路由配置index.js

// 匹配404，即路径未匹配时
app.use(function (req, res, next) {
    var err     = new Error('Not Found');
    err.status  = 404;
    next(err);
});

module.exports  = app;