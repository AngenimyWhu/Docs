# 使用node.js + express开发简易web服务
### 开发环境 node.js + express 

## 使用方式
```
# 使用淘宝镜像安装cnpm
    npm install -g cnpm --registry=https://registry.npm.taobao.org
# 安装express
    npm install -g express
# 安装项目依赖
    cd <path-to-nodejs express>
    cnpm install
# 启动项目
    cnpm start
```

## 项目目录
* bin/
    - wes   ----------------------------项目入口文件
* dist/
    - js/   -----------------------------js文件       
    - css/  ---------------------------css文件
* node_modules/   ---------项目依赖文件夹，cnpm intall后生成 
* routes/   -------------------路由配置文件夹(可添加其他页面的路由配置)
    - index.js -----------------------首页的路由配置
* ssl/   ----------------------HTTPs证书文件
    - priv.key
	- server.pem
* views/    -------------------模板文件(可添加其他页面)
    - index.ejs ----------------------首页的模板
* app.js   --------------------存放的Express项目中最基本的配置信息
* package.json   ------------项目依赖文件
            
## 文件解析

### wes
wes文件为web服务的启动配置，核心是使用HTTPS证书配置https服务器.

```
#!/usr/bin/env node
const https   = require('https'); // https服务器
const fs      = require('fs');    // 文件输入输出，用来导入证书
const app     = require('../app');// 对应于app.js文件
const SSLPORT = 443;              // 端口号

// 读取证书---注意相对路径
const credentials = {
    key : fs.readFileSync('ssl/priv.key',   'utf8'),
    cert: fs.readFileSync('ssl/server.pem', 'utf8')
}

// 启动web服务
https.createServer(credentials, app).listen(SSLPORT, function(){
    console.log('HTTPS Server is running');
});   
```


### app.js
// web服务的管理入口
```
var express = require('express');
var path    = require('path');
var index   = require('./routes/index');                // 引入index.js路由配置文件

var app = express();                                    // 用express创建一个app应用
// view engine setup
app.set('views',       path.join(__dirname, 'views'));  // 指定视图文件夹 views/
app.set('view engine', 'ejs');                          // 指定视图引擎 ejs
// 全局跨域设置
app.all('*', (req, res, next) => {
    res.header('Access-Control-Allow-Origin',  '*');
    res.header('Cross-Origin-Embedder-Policy', 'require-corp');
    res.header('Cross-Origin-Opener-Policy',   'same-origin'); 
    next();
})

// 设置静态资源路径
app.use(express.static(path.join(__dirname, 'dist')));  // 指定公共资源文件夹 为public/
// 路由规则
app.use('/', index);                                    // 当路径为'/'，即'https://localhost:443/'时，匹配路由配置index.js

// 匹配404，即路径未匹配时
app.use(function (req, res, next) {
    var err     = new Error('Not Found');
    err.status  = 404;
    next(err);
});

module.exports  = app;
```
